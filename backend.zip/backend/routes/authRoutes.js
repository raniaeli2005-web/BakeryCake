const express = require('express');
const router = express.Router();
// Si authRoutes.js está dentro de 'routes' y authController.js dentro de 'controllers'
const authController = require('../controllers/authController');

router.post('/register', authController.register);
router.post('/login', authController.login);

module.exports = router;