const sql = require('mssql');

const config = {
    server: '127.0.0.1', 
    port: 1433,
    database: 'bakery',
    options: {
        encrypt: false,
        trustServerCertificate: true,
        trustedConnection: true
},
};

// Intentar conectar
const poolPromise = new sql.ConnectionPool(config).connect()
    .then(pool => {
        console.log("¡CONEXIÓN ESTABLECIDA!");
        return pool;
    })
    .catch(err => {
        console.error("ERROR DETALLADO:", err);
    });

module.exports = { sql, poolPromise };