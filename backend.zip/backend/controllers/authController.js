const { poolPromise } = require('../database/db');
const bcrypt = require('bcryptjs');

exports.register = async (req, res) => {
    const { nombre, correo, contrasena, rol } = req.body;
    console.log("Intentando buscar correo:", correo); // <--- AGREGA ESTO
    try {
        const pool = await poolPromise;
        
        // 1. Encriptar contraseña
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(contrasena, salt);

        // 2. Insertar en la BD
        const result = await pool.request()
            .input('nombre', nombre)
            .input('correo', correo)
            .input('contrasena', hash)
            .input('rol', rol || 'cliente')
            .query("INSERT INTO [dbo].[Usuarios] (nombre, correo, contrasena, rol) VALUES (@nombre, @correo, @contrasena, @rol)");

        res.status(201).json({ message: "Registro guardado correctamente en la BD" });
    } catch (err) {
        console.error("Error al registrar:", err);
        res.status(500).json({ message: "Error al guardar en base de datos", error: err.message });
    }
};

exports.login = async (req, res) => {
    const { correo, contrasena } = req.body;

    try {
        const pool = await poolPromise;
        
        // 1. Buscamos el usuario por su correo
        const result = await pool.request()
            .input('correo', correo)
            .query("SELECT * FROM [dbo].[Usuarios] WHERE correo = @correo");

        // 2. Si el usuario no existe
        if (result.recordset.length === 0) {
            return res.status(401).json({ message: "Usuario no encontrado" });
        }

        const usuario = result.recordset[0];

        // 3. Comparamos la contraseña enviada con la guardada en la base de datos
        const esValida = await bcrypt.compare(contrasena, usuario.contrasena);

        if (!esValida) {
            return res.status(401).json({ message: "Contraseña incorrecta" });
        }

        // 4. Si todo es correcto
        res.status(200).json({ 
            message: "Login exitoso", 
            usuario: { id: usuario.id_usuario, nombre: usuario.nombre, rol: usuario.rol } 
        });

    } catch (err) {
        console.error("Error en login:", err);
        res.status(500).json({ message: "Error en el servidor" });
    }
};