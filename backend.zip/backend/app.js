const express = require('express');
const app = express();

// IMPORTANTE: Esto debe estar antes de las rutas
app.use(express.json());

const authRoutes = require('./routes/authRoutes');

// Montar las rutas
app.use('/api/auth', authRoutes);

app.listen(5000, () => {
    console.log('Servidor corriendo en puerto 5000');
});