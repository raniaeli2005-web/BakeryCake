const { poolPromise } = require('./database/db'); // Asegúrate que la ruta sea esta

async function testConnection() {
    try {
        console.log("Intentando conectar...");
        const pool = await poolPromise; // Espera a que la promesa se resuelva
        const result = await pool.request().query('SELECT 1 as test');
        console.log('¡Conexión exitosa! Resultado de prueba:', result.recordset);
    } catch (err) {
        console.error('La conexión falló:', err);
    } finally {
        process.exit(); // Esto cierra el proceso después de probar
    }
}

testConnection();